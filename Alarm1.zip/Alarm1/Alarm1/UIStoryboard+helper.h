//
//  UIStoryboard+helper.h
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIStoryboard (helper)

+(UIStoryboard*)getMenuStoryBoad;
+(UIStoryboard*)getRightStoryBoad;

@end
