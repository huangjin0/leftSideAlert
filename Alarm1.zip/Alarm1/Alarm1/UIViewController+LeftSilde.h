//
//  UIViewController+LeftSilde.h
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LeftSlideViewController;
@interface UIViewController (LeftSilde)

@property(strong,readonly,nonatomic)LeftSlideViewController*sideMenuViewController;

-(IBAction)presentLeftMenuViewController:(id)sender;
@end
