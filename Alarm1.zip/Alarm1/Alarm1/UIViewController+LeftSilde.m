//
//  UIViewController+LeftSilde.m
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "UIViewController+LeftSilde.h"
#import "LeftSlideViewController.h"
@implementation UIViewController (LeftSilde)
- (LeftSlideViewController *)sideMenuViewController
{
    UIViewController *iter = self.parentViewController;
    while (iter) {
        if ([iter isKindOfClass:[LeftSlideViewController class]]) {
            return (LeftSlideViewController *)iter;
        } else if (iter.parentViewController && iter.parentViewController != iter) {
            iter = iter.parentViewController;
        } else {
            iter = nil;
        }
    }
    return nil;
}

#pragma mark action
-(IBAction)presentLeftMenuViewController:(id)sender
{
    [self.sideMenuViewController openLeftView];

}

@end
