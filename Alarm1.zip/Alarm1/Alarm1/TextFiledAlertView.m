//
//  TextFiledAlertView.m
//  Alarm1
//
//  Created by huangjin on 16/2/25.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "TextFiledAlertView.h"

@implementation TextFiledAlertView

- (id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitles, ... {
    self = [super initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:otherButtonTitles, nil];
    if (self != nil) {
        // 初始化自定义控件，注意摆放的位置，可以多试几次位置参数直到满意为止
        // createTextField函数用来初始化UITextField控件，在文件末尾附上
        self.name = [self AddTextField:CGRectMake(22, 45, 240, 36)];
        [self addSubview:self.name];
    }
    return self;
}


-(void)layoutSubviews {
    [super layoutSubviews];
    for (UIView* view in self.subviews) {
      
        if ([view isKindOfClass:[UIButton class]] ||
            [view isKindOfClass:NSClassFromString(@"UIThreePartButton")]) {
            CGRect ButtonBounds = view.frame;
           ButtonBounds.origin.y = self.name.frame.origin.y + 10;
            view.frame = ButtonBounds;
        }
    }
    CGRect bounds = self.frame;
    bounds.size.height = 300;
    self.frame = bounds;
    
}
- (UITextField*)AddTextField:(CGRect)frame {
    UITextField* field = [[UITextField alloc] initWithFrame:frame];
//    field.placeholder = 
//    field.secureTextEntry = YES;
    field.backgroundColor = [UIColor redColor];
    field.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    return field;
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    self.backgroundColor=[UIColor redColor];
}


@end
