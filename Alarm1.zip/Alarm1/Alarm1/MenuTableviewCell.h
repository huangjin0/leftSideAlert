//
//  MenuTableviewCell.h
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  左边视图TableViewcell
 */
@interface MenuTableviewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *leftTitle;
@property (weak, nonatomic) IBOutlet UIImageView *leftImage;

@end
