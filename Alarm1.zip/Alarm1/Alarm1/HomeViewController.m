//
//  HomeViewController.m
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "HomeViewController.h"
#import "LocalNotificationManager.h"
//#import "LeftSlideViewController.m"
//#import "RootViewController.h"
#import "AddAlarmViewController.h"
#import "FMManager.h"


#import "AlarmManager.h"

@interface HomeViewController ()
{
LeftSlideViewController*left;

}
@end

@implementation HomeViewController

#pragma mark-- IBACtion
- (IBAction)showMenu:(id)sender {
    //发送通知显示左边菜单栏
   [[NSNotificationCenter defaultCenter]postNotificationName:@"left" object:nil userInfo:nil];
   
}
- (IBAction)addAlerm:(id)sender {
    //添加闹钟并发送通知关闭左侧菜单栏
    AddAlarmViewController*addAlarm=[self.storyboard instantiateViewControllerWithIdentifier:@"AddAlarmViewController"];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":addAlarm}];
    
}


#pragma  test
- (IBAction)clickDataBase:(id)sender {
    UIButton*bt=(UIButton*)sender;
     FMManager*fm=[FMManager shareInstance];
//    @property(nonatomic,copy)NSString      *alarmId;
//    @property (nonatomic,copy) NSString     *alarmDate;//响铃日期
//    @property (nonatomic,assign) BOOL       alarmEnable;//开启关闭闹钟  YES为开启NO为关闭
//    @property (nonatomic,copy  ) NSString   *alarmName;//闹钟名字
//    @property (nonatomic,assign) NSUInteger alarmRepeat;//重复周期
//    @property (nonatomic,assign) NSData     *alarmMusic;//闹钟音乐
//    @property (nonatomic,assign) double     alarmVolume;//闹钟音量
//    @property (nonatomic,assign) NSInteger  alarmSnooze;//贪睡时间
//    @property (nonatomic,assign) BOOL       alarmEnableVibration;//开启关闭震动 YES为开启，NO为关闭
//    @property (nonatomic,assign) BOOL       alarmEnableAdvanceIN;//恶劣天气是否提前响铃  YES为开启，NO为关闭
//    @property (nonatomic,assign) NSInteger  alarmAdvanceTimeIN;//恶劣天气提前时间
//    @property (nonatomic,assign) BOOL       alarmEnableAdvanceTR;//电车是否提前响铃
//    @property (nonatomic,copy  ) NSString   *alarmTramTR;//电车编号
//    @property (nonatomic,assign) NSInteger  alarmAdvanceTimeTR;//电车提前时间
    if(bt.tag==0)
    {//删除
    
        [fm deleteAlarmForLocalBaseL:@"id2"];
    }
    if(bt.tag==1)
    {
//        插入
       AlarmManager *manager=[[AlarmManager alloc]init];
        manager.alarmId=@"id2";
        manager.alarmDate=@"14:12";
        manager.alarmEnable=YES;
        manager.alarmName=@"脑装一";
        manager.alarmRepeat=4;
        manager.alarmMusic=[@"音乐" dataUsingEncoding:NSUTF8StringEncoding];
        manager.alarmVolume=45;
        manager.alarmSnooze=15;
        manager.alarmEnableVibration=YES;
        manager.alarmAdvanceTimeIN=1;
        manager.alarmEnableAdvanceIN=YES;
        manager.alarmEnableAdvanceTR=YES;
        manager.alarmAdvanceTimeTR=12;
        manager.alarmTramTR=@"电车编号1";
        [fm insertAlarmForLocalBase:manager];
        
        
    }
    if(bt.tag==2)
    {
//        编辑
   
        AlarmManager *manager=[[AlarmManager alloc]init];
        manager.alarmId=@"id2";
        manager.alarmDate=@"14:12";
        manager.alarmEnable=YES;
        manager.alarmName=@"脑装一";
        manager.alarmRepeat=4;
        manager.alarmMusic=[@"音乐" dataUsingEncoding:NSUTF8StringEncoding];
        manager.alarmVolume=45;
        manager.alarmSnooze=15;
        manager.alarmEnableVibration=YES;
        manager.alarmAdvanceTimeIN=1;
        manager.alarmEnableAdvanceIN=YES;
        manager.alarmEnableAdvanceTR=YES;
        manager.alarmAdvanceTimeTR=12;
        manager.alarmTramTR=@"电车77888adsafjddkl编号1";
        [fm alertAlarmForLocalBase:manager];
        
    }
    
    if (bt.tag==4) {
        
        AlarmManager *managers=[fm queryAlarmforLocalBase:@"id1"];
        NSLog(@"managers:%@",managers.alarmTramTR);

    }

}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //发送通知打开手势开关
    [[NSNotificationCenter defaultCenter]postNotificationName:@"OpenPan" object:nil userInfo:nil];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor redColor];
    
    
                       
//    LocalNotificationManager*a=[[LocalNotificationManager alloc]init];
//    [a OpenAlert];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
