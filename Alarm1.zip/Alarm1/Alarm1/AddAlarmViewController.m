//
//  AddAlarmClock.m
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "AddAlarmViewController.h"
#import "LocalNotificationManager.h"
#import "TextFiledAlertView.h"
#import "XYInputView.h"
#import <MediaPlayer/MediaPlayer.h>



@interface AddAlarmViewController()<MPMediaPickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UIDatePicker *datepicker;
@property (weak, nonatomic) IBOutlet UILabel *startAlarmLabel;
@property (weak, nonatomic) IBOutlet UISwitch *aleramEnable;
@property (weak, nonatomic) IBOutlet UILabel *alarmTitle;
@property (weak, nonatomic) IBOutlet UILabel *alarmCycle;
@property (weak, nonatomic) IBOutlet UILabel *alarmMusic;
@property (weak, nonatomic) IBOutlet UILabel *alarmSound;
@property (weak, nonatomic) IBOutlet UILabel *alarmSettingLabel;

@end
@implementation AddAlarmViewController

#pragma mark --IBAction

- (IBAction)clickSelect:(id)sender {
    UIButton* button=(UIButton*)sender;
    NSInteger tag=button.tag;
    if (tag==SelectAddTitle) {
        [self addTitle];
    }if (tag==SelectAddMusic) {
        [self selecMusic];
    }
    

}
#pragma mark --PrivateMethond

-(void)addTitle
{
// TextFiledAlertView*alert=[[TextFiledAlertView alloc]initWithTitle:@"rename" message:nil delegate:self cancelButtonTitle:@"cacel" otherButtonTitles:@"确定", nil];
//   [alert show];
   
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"rename"
                                                                              message:@""
                                                                       preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.frame=CGRectMake(0, 0, 320, 100);
        
        textField.placeholder = @"Add Alarm clock";
       textField.backgroundColor=ALERTCONTROLLERTEXTFOLOOR;
        textField.textColor = [UIColor whiteColor];
        textField.tintColor=BLACK;
//        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
//        textField.borderStyle= UITextBorderStyleBezel;
     textField.layer.borderWidth=1;
        textField.layer.borderColor=BLACK.CGColor;
    }];
    alertController.currentStyle.blurEffectStyle = UIBlurEffectStyleDark;
    alertController.currentStyle.backgroundColor=ALERTCONTROLLERBCOLOOR;
    alertController.currentStyle.shouldApplyBlur = YES;
    alertController.currentStyle.destructiveButtonColor = [UIColor colorWithHue:0.13 saturation:0.94 brightness:0.95 alpha:1];
    [alertController addAction:[UIAlertAction actionWithTitle:@"cacel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        UITextField * namefield = textfields[0];
        
        NSLog(@"%@",namefield.text);
        
    }]];

    
    
    [self presentViewController:alertController animated:YES completion:nil];

    

}

-(void)selecMusic
{
    MPMediaPickerController*musicController=[[MPMediaPickerController alloc]init];
//    musicController.prompt=@"请选择歌曲";
    musicController.showsCloudItems=NO;
    musicController.allowsPickingMultipleItems=NO;
    musicController.delegate=self;
    [self presentViewController:musicController animated:YES completion:nil];
    
    

}

#pragma mark--  controller cycle
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

}
-(void)viewDidLoad
{
    [super viewDidLoad];
//    LocalNotificationManager*local=[[LocalNotificationManager alloc]init];
//    [local OpenAlert];
}



#pragma mark --MPMediaPickerControllerDelegate
- (void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
      [mediaPicker dismissViewControllerAnimated:YES completion:^{
    
      }];
    
    
}
- (void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker;
{
    [mediaPicker dismissViewControllerAnimated:YES completion:nil];
}

@end
