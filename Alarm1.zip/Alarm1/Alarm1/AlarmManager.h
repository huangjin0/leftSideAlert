//
//  AlarmManager.h
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AlarmManager : NSObject
@property(nonatomic,copy)NSString      *alarmId;
@property (nonatomic,copy) NSString     *alarmDate;//响铃日期
@property (nonatomic,assign) BOOL       alarmEnable;//开启关闭闹钟  YES为开启NO为关闭
@property (nonatomic,copy  ) NSString   *alarmName;//闹钟名字
@property (nonatomic,assign) NSUInteger alarmRepeat;//重复周期
@property (nonatomic,assign) NSData     *alarmMusic;//闹钟音乐
@property (nonatomic,assign) double     alarmVolume;//闹钟音量
@property (nonatomic,assign) NSInteger  alarmSnooze;//贪睡时间
@property (nonatomic,assign) BOOL       alarmEnableVibration;//开启关闭震动 YES为开启，NO为关闭
@property (nonatomic,assign) BOOL       alarmEnableAdvanceIN;//恶劣天气是否提前响铃  YES为开启，NO为关闭
@property (nonatomic,assign) NSInteger  alarmAdvanceTimeIN;//恶劣天气提前时间
@property (nonatomic,assign) BOOL       alarmEnableAdvanceTR;//电车是否提前响铃
@property (nonatomic,copy  ) NSString   *alarmTramTR;//电车编号
@property (nonatomic,assign) NSInteger  alarmAdvanceTimeTR;//电车提前时间

@end
