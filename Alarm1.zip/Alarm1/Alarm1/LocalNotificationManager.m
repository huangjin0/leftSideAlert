//
//  LocalNotificationManager.m
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "LocalNotificationManager.h"
#import<AudioToolbox/AudioToolbox.h>

@interface LocalNotificationManager()
{
    UILocalNotification*_notification;

}
@end

 NSInteger AppIConNumber=0;

@implementation LocalNotificationManager


#pragma mark -init
-(id)init
{
    self=[super init];
    if (self) {
        
        _notification=[[UILocalNotification alloc]init];
    }
    return self;

}

#pragma mark --public方法


-(void)OpenAlert
{
    if (_notification!=nil) {
        
        NSDate *now=[NSDate new];
        _notification.fireDate=[now dateByAddingTimeInterval:2];//多少秒后通知
        _notification.timeZone=[NSTimeZone defaultTimeZone];//时区
        _notification.repeatInterval=0;//循环次数，kCFCalendarUnitWeekday一周一次
        _notification.repeatCalendar=nil;//重复日期，
        _notification.applicationIconBadgeNumber=AppIConNumber++; //AppIconBage
        _notification.soundName= UILocalNotificationDefaultSoundName;//声音，可以换成alarm.soundName = @"myMusic.caf"
        _notification.alertBody=@"通知内容";//提示信息 弹出提示框
        _notification.alertAction = @"打开";  //提示框按钮
       _notification.hasAction = YES; //是否显示额外的按钮，为no时AlertAction消失
        _notification.category=self.alertCategory;
        _notification.userInfo = self.userInfo; //添加额外的信息
        [[UIApplication sharedApplication] scheduleLocalNotification:_notification];
    }

}
-(void)cancelLocalnotification:(NSString*)category
{
    NSArray*notifications=[[UIApplication sharedApplication]scheduledLocalNotifications];
    for (UILocalNotification*obj in notifications) {
        if ([obj.category isEqualToString:category]) {
             [[UIApplication sharedApplication] cancelLocalNotification:obj];
        }
        
    }

}
@end
