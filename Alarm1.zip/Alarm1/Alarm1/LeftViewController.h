//
//  LeftViewController.h
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  自定义左视图controller
 */
@interface LeftViewController : UIViewController

@end
