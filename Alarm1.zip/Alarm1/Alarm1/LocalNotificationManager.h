//
//  LocalNotificationManager.h
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LocalNotificationManager : NSObject

@property (nonatomic,assign) NSInteger         firedate;//间隔
@property (nonatomic,assign) NSCalendarUnit calendarUnit;//重复周期
@property (nonatomic,copy  ) NSString       *soundName;//声音
@property (nonatomic,copy  ) NSString       *alertConntent;//通知内容
@property (nonatomic,copy  ) NSString       *alertCategory;//notificationIdentifer;
@property (nonatomic,strong) NSDictionary   *userInfo;//用户信息





-(void)OpenAlert;
@end
