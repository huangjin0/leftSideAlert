//
//  NSDate+weeks.m
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "NSDate+weeks.h"
#import <Foundation/Foundation.h>

@implementation NSDate (weeks)

//获取当前日期详情
+(NSDateComponents*)getdateCompets
{
    NSCalendar *calendar;
    calendar=[[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *now;
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekday |
    NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    now=[NSDate date];
    comps = [calendar components:unitFlags fromDate:[NSDate date]];
    return comps;
}

//获取选择的日期和当前日期之间的间隔
+(NSInteger)getIntervaldate:(NSInteger)hous minutes:(NSInteger)min
{
    NSDateComponents*com=[NSDate getdateCompets];
    NSInteger currentTotal=com.hour*60*60+com.minute*60+com.second;
    NSInteger seletTotal=hous*60*60+min*60;
    NSInteger intervaltime;
    if (currentTotal<seletTotal) {//如果选择的日期大于当前日期直接做差
        
        intervaltime=seletTotal-currentTotal;
        
    }else
    {
        intervaltime=24*60*60-(currentTotal-seletTotal);
    }
    
    return intervaltime;
}


@end
