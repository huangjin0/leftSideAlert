//
//  MenuViewController.m
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "MenuViewController.h"
#import "MenuTableviewCell.h"
#import "UIViewController+RESideMenu.h"


#import "WallPaperViewController.h"
#import "WeatherViewController.h"
#import "FAQViewController.h"
#import "SystemNotiViewController.h"
#import "ShareViewController.h"

@interface MenuViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

static NSString*cellIndentifer=@"MenuTableviewCell";
@implementation MenuViewController

#pragma mark Controller-Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setColor];
    [self setTableViewHeader];

}

#pragma mark-
#pragma mark Private Methond

-(void)setColor
{
     self.view.backgroundColor=MENUBACKGROUNDCOLOR;

}

-(void)setTableViewHeader
{
    UIView*view=XIB(@"MenuHeader");
    view.frame=CGRectMake(0, 0, 320, 100);
    self.tableView.tableHeaderView=view;
}

#pragma mark -- TableViewDatasource
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;

}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MenuTableviewCell*cell=[tableView dequeueReusableCellWithIdentifier:cellIndentifer forIndexPath:indexPath];
    cell.leftTitle.text=@"";
    cell.leftImage.image=[UIImage imageNamed:@"wallPaper"];
   
    return cell;

}

#pragma mark --tableviewDelegate

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        
        case WallPaper:
        {
            WallPaperViewController*vc=[[UIStoryboard getMenuStoryBoad ]instantiateViewControllerWithIdentifier:@"WallPaperViewController"];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":vc}];
            break;
        }
    case Weather:
        {
        
            WeatherViewController*vc=[[UIStoryboard getMenuStoryBoad ]instantiateViewControllerWithIdentifier:@"WeatherViewController"];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":vc}];
            
            break;
            

        }
    case FAQ:
        {
            FAQViewController*vc=[[UIStoryboard getMenuStoryBoad ]instantiateViewControllerWithIdentifier:@"FAQViewController"];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":vc}];

            
        
            break;
        }
            
    case SystemNotification:
        {
            
            SystemNotiViewController*vc=[[UIStoryboard getMenuStoryBoad ]instantiateViewControllerWithIdentifier:@"SystemNotiViewController"];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":vc}];
            break;
        
        }
           
    case Share:
        {
            ShareViewController*vc=[[UIStoryboard getMenuStoryBoad ]instantiateViewControllerWithIdentifier:@"ShareViewController"];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"CloseLeft" object:nil userInfo:@{@"vc":vc}];
            break;
        }
            
        default:
            ;
           break;
            
    }
   
    
    
    


}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
