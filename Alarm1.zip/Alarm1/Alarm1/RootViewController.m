//
//  ViewController.m
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "RootViewController.h"


@interface RootViewController ()
@end

@implementation RootViewController

#pragma mark --init
-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        
    }
    return self;
    
}



-(void)awakeFromNib
{
    [super awakeFromNib];

}
#pragma mark controller-cycle

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   

}
- (void)viewDidLoad {
    [super viewDidLoad];

    
    // Do any additional setup after loading the view, typically from a nib.
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
