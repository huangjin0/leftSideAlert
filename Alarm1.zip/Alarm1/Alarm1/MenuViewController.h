//
//  MenuViewController.h
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RESideMenu.h"

@interface MenuViewController : UIViewController <RESideMenuDelegate>

@end
