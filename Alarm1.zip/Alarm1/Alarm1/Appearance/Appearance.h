//
//  Appearance.h
//  Project
//
//  Created by doorxp on 14/12/23.
//  Copyright (c) 2014年 doorxp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Appearance : NSObject

+ (void)loadDefaultStyle;

@end
