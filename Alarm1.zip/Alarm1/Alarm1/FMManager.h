//
//  FMManager.h
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AlarmManager.h"
@interface FMManager : NSObject
+(id)shareInstance;
-(INSERTDATABASRRESULT)insertAlarmForLocalBase:(AlarmManager*)obj;
-(void)deleteAlarmForLocalBaseL:(NSString*)alarmID;
-(void)alertAlarmForLocalBase:(AlarmManager*)obj;
-(AlarmManager*)queryAlarmforLocalBase:(NSString*)alarmID;

@end
