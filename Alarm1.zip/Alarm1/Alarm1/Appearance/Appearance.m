//
//  Appearance.m
//  Project
//
//  Created by doorxp on 14/12/23.
//  Copyright (c) 2014年 doorxp. All rights reserved.
//

#import "Appearance.h"
#import <UIKit/UIKit.h>

@implementation Appearance

+ (void)loadDefaultStyle
{
#pragma mark - UINavigationBar
  [[UINavigationBar appearance]setBarTintColor:BARBACKGROUNDCOLOR];
  [[UINavigationBar appearance]setBackgroundColor:BARBACKGROUNDCOLOR];
//    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:WHITE, NSFontAttributeName: [UIFont fontWithName:fontNameDefault size:18]}];
    [[UINavigationBar appearance] setTintColor:WHITE];
    
    
    
#pragma mark - UIBarButtonItem
    [[UIBarButtonItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:WHITE} forState:UIControlStateNormal];
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -60) forBarMetrics:UIBarMetricsDefault];
    [[UIToolbar appearance] setBarTintColor:COLOR(37, 229, 254, 1.0)];//(37, 229, 254)/*[UIColor colorWithString:@"#C5252C"]*/];
    [[UIToolbar appearance] setTintColor:WHITE];
    
#pragma mark -UIToolBar
//    [[UIToolbar appearance]setBarTintColor:MAINCOLOR];

}

@end
