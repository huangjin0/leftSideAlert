//
//  WakeUpView.m
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "WakeUpView.h"
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>


@interface WakeUpView()
{
    BOOL isContinue_;// 是否继续播放

}
@property(nonatomic,strong)NSTimer*timer;
@end

@implementation WakeUpView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

#pragma mark - init

-(id)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
    }
    return self;

}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    if (self=[super initWithCoder:aDecoder]) {
        
    }
    return self;
}

-(void)awakeFromNib
{
    

}


#pragma mark --publicMethond
-(void)playSunds:(UILocalNotification*)notifaction
{
    _timer=[NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(play) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSDefaultRunLoopMode];//加入RunLoop以免被延时
    [_timer fire];//启动
   

}


#pragma mark --Private Methond
-(void)play
{

    if(isContinue_==NO)
    {
//        [AVAudioPlayer alloc]initWithData:<#(nonnull NSData *)#> fileTypeHint:<#(NSString * _Nullable)#> error:<#(NSError * _Nullable __autoreleasing * _Nullable)#>
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        NSLog(@"play");
        
        
    }
    else
    {
        [_timer invalidate];//销毁
    
    }
    

}

@end
