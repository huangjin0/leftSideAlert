//
//  AudioPlayManeger.h
//  Alarm1
//
//  Created by huangjin on 16/2/25.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AudioPlayManeger : NSObject
-(void)playAudioPlayManager;
@end
