//
//  MenuTableviewCell.m
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "MenuTableviewCell.h"

@implementation MenuTableviewCell

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor=MENUBACKGROUNDCOLOR;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
