//
//  UIStoryboard+helper.m
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "UIStoryboard+helper.h"

@implementation UIStoryboard (helper)
//获取MenuStoryBoad
+(UIStoryboard *)getMenuStoryBoad
{
    return [self storyboardWithName:@"Menu" bundle:nil];

}
//获取右边storyboad
+(UIStoryboard*)getRightStoryBoad
{
    return [self storyboardWithName:@"Right" bundle:nil];
}
@end
