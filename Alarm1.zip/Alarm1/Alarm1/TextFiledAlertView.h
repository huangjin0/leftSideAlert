//
//  TextFiledAlertView.h
//  Alarm1
//
//  Created by huangjin on 16/2/25.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFiledAlertView : UIAlertView

@property(nonatomic,retain)UITextField*name;

@end
