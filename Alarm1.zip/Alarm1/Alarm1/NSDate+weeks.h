//
//  NSDate+weeks.h
//  Alarm1
//
//  Created by huangjin on 16/2/24.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (weeks)
+(NSDateComponents*)getdateCompets;
+(NSInteger)getIntervaldate:(NSInteger)hous minutes:(NSInteger)min;
@end
