//
//  CommonDefine.h
//  Alarm1
//
//  Created by huangjin on 16/2/22.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#ifndef CommonDefine_h
#define CommonDefine_h





/**
 * 全局变量
 */

extern NSInteger AppIConNumber;

/*
 * ------------------------- 背景颜色类定义----------------------
 */
#define MENUBACKGROUNDCOLOR  COLOR(254,193,137,1)//左侧菜单背景色
#define BARBACKGROUNDCOLOR   COLOR(47,196,136,1)//导航条背景色


/*  增加闹钟*/
#define ALERTCONTROLLERBCOLOOR COLOR(254,194,84,1)//alert背景色
#define ALERTCONTROLLERTEXTFOLOOR COLOR(130,115,82,1)//alertTextfiled颜色

#define  MENUSTORYBOAD  [UIStoryboard storyboardWithName:@"Menu" bundle:nil];//Menu的storyboad

/*
 *  应用数据枚举
 */
typedef enum : NSUInteger {
    WallPaper          = 0,//墙纸
    Weather            = 1,//天气
    FAQ                = 2,//FAQ
    SystemNotification = 3,//系统通知
    Share              = 4,//分享
    FiveStarPraise     = 5,//五星评价
    AppPromotion       = 6,//应用推荐
    
} MenuType;//左侧菜单选项

typedef enum :NSUInteger{
    Everyday   = 10,//每天
    Weekdays   = 11,//工作日
    Weekends   = 12,//周末
    CustomDate = 33,//自定义
}RepeatType;//周期类型

typedef enum :NSUInteger{
    Sunday    = 1,//周末
    Monday    = 2,//周一
    Tuesday   = 3,
    Wednesday = 4,
    Thursday  = 5,
    Friday    = 6,
    Saturday  = 7,
   
    
}WeekUnitType;

//增加和编辑闹钟ButtonTag值枚举
typedef enum : NSInteger
{
    SelectAddTitle         = 1,
    SelectAddMusic         = 2,
    SelectAddSound         = 3,
    SelectAdvanceSettings  = 4,//高级设置
    SelectAddSnoozeTime    = 5,//贪睡时间
    SelectAddAdVanceTimeIN = 6,//恶劣天气提前时间
    SelectAddTramTR        = 7,//电车选择
    SelectAddAdvanceTimeTR = 8,//电车提前时间

}AddAlarmSelectTag;
typedef enum : NSInteger
{
    SelectEditTitle           = 1,
    SelectEditMusic           = 2,
    SelectEditSound           = 3,
    SelectEditAdvanceSettings = 4,//高级设置
    SelectEditSnoozeTime      = 5,//贪睡时间
    SelectEditAdVanceTimeIN   = 6,//恶劣天气提前时间
    SelectEditTramTR          = 7,//电车选择
    SelectEditAdvanceTimeTR   = 8,//电车提前时间
    
}EditAlarmSelectTag;
/**
 数据库操作
 */
typedef enum :NSInteger
{
    INSERTERROR        = 1,//插入失败
    INSERTDATAIDSANMES = 2,//数据库已经有相同的数据
    INSERTSUCESS       = 3,//插入成功

}INSERTDATABASRRESULT;


#endif /* CommonDefine_h */
