//
//  LeftViewController.m
//  Alarm1
//
//  Created by huangjin on 16/2/23.
//  Copyright © 2016年 zhixun. All rights reserved.
//

#import "LeftViewController.h"
#import "UIViewController+RESideMenu.h"

@interface LeftViewController ()

@end

@implementation LeftViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setBackBarItem];
    // Do any additional setup after loading the view.
}

-(void)setBackBarItem
{
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithTitle:@"返回去" style:UIBarButtonItemStylePlain target:self action:@selector(backMainControlelr:)];
    self.navigationItem.leftBarButtonItem=item;

}

-(IBAction)backMainControlelr:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"left" object:nil userInfo:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
